Imports System.Collections.Generic
Imports System.Diagnostics
Imports System.IO
Imports System.IO.Ports
Imports System.Threading

Friend NotInheritable Class RobustModbusRtuMaster
    Implements IDisposable

    Private Const ResponseTimeoutMs As Integer = 6000
    Private Const InterFrameDelayMs As Integer = 400
    Private Const RetryDelayMs As Integer = 800
    Private Const QuietDrainMs As Integer = 300
    Private Const MaxAttempts As Integer = 3

    Private ReadOnly _port As SerialPort
    Private ReadOnly _slaveId As Byte
    Private ReadOnly _sync As New Object()

    Public Sub New(portName As String, baud As Integer, slaveId As Byte)
        _slaveId = slaveId

        _port = New SerialPort(portName, baud, Parity.None, 8, StopBits.One) With {
            .Handshake = Handshake.None,
            .ReadTimeout = 250,
            .WriteTimeout = 3000,
            .DtrEnable = False,
            .RtsEnable = False,
            .ReadBufferSize = 8192,
            .WriteBufferSize = 4096
        }
    End Sub

    Public Sub Open()
        SyncLock _sync
            If _port.IsOpen Then Return

            _port.Open()
            Thread.Sleep(500)
            DrainUntilQuiet()
        End SyncLock
    End Sub

    Public Function ReadHoldingRegisters(
        startAddress As UShort,
        quantity As UShort) As UShort()

        SyncLock _sync
            Dim request(7) As Byte
            request(0) = _slaveId
            request(1) = &H3
            PutU16(request, 2, startAddress)
            PutU16(request, 4, quantity)
            AppendCrc(request)

            Dim expectedLength As Integer = 5 + CInt(quantity) * 2
            Dim lastError As Exception = Nothing

            For attempt As Integer = 1 To MaxAttempts
                Try
                    PrepareTransaction()
                    _port.Write(request, 0, request.Length)

                    Dim frame = ReadMatchingFrame(&H3, expectedLength)

                    If frame(2) <> CByte(quantity * 2) Then
                        Throw New IOException("Λάθος byte count.")
                    End If

                    Dim registers(CInt(quantity) - 1) As UShort

                    For i As Integer = 0 To registers.Length - 1
                        registers(i) = GetU16(frame, 3 + i * 2)
                    Next

                    Thread.Sleep(InterFrameDelayMs)
                    Return registers

                Catch ex As Exception
                    lastError = ex
                    If attempt < MaxAttempts Then Thread.Sleep(RetryDelayMs)
                End Try
            Next

            Throw New IOException("FC03 απέτυχε μετά από retries.", lastError)
        End SyncLock
    End Function

    Public Sub WriteMultipleRegisters(
        startAddress As UShort,
        values As UShort())

        SyncLock _sync
            Dim dataBytes As Integer = values.Length * 2
            Dim request(9 + dataBytes - 1) As Byte

            request(0) = _slaveId
            request(1) = &H10
            PutU16(request, 2, startAddress)
            PutU16(request, 4, CUShort(values.Length))
            request(6) = CByte(dataBytes)

            For i As Integer = 0 To values.Length - 1
                PutU16(request, 7 + i * 2, values(i))
            Next

            AppendCrc(request)

            Dim lastError As Exception = Nothing

            For attempt As Integer = 1 To MaxAttempts
                Try
                    PrepareTransaction()
                    _port.Write(request, 0, request.Length)

                    Dim response = ReadMatchingFrame(&H10, 8)

                    If GetU16(response, 2) <> startAddress OrElse
                       GetU16(response, 4) <> values.Length Then
                        Throw New IOException("Λάθος FC16 echo.")
                    End If

                    Thread.Sleep(InterFrameDelayMs)
                    Return

                Catch ex As Exception
                    lastError = ex
                    If attempt < MaxAttempts Then Thread.Sleep(RetryDelayMs)
                End Try
            Next

            Throw New IOException("FC16 απέτυχε μετά από retries.", lastError)
        End SyncLock
    End Sub

    Private Sub PrepareTransaction()
        DrainUntilQuiet()
        Thread.Sleep(InterFrameDelayMs)
    End Sub

    Private Sub DrainUntilQuiet()
        Dim timer = Stopwatch.StartNew()
        Dim lastByteAt As Long = timer.ElapsedMilliseconds

        While timer.ElapsedMilliseconds < 1800
            Dim available As Integer = _port.BytesToRead

            If available > 0 Then
                Dim garbage(Math.Min(available, 1024) - 1) As Byte
                _port.Read(garbage, 0, garbage.Length)
                lastByteAt = timer.ElapsedMilliseconds
            ElseIf timer.ElapsedMilliseconds - lastByteAt >= QuietDrainMs Then
                Exit While
            Else
                Thread.Sleep(20)
            End If
        End While
    End Sub

    Private Function ReadMatchingFrame(
        expectedFunction As Byte,
        expectedLength As Integer) As Byte()

        Dim received As New List(Of Byte)()
        Dim timer = Stopwatch.StartNew()

        While timer.ElapsedMilliseconds < ResponseTimeoutMs
            Try
                Dim value As Integer = _port.ReadByte()
                If value >= 0 Then received.Add(CByte(value))
            Catch ex As TimeoutException
                Thread.Sleep(10)
            End Try

            Dim frame = ExtractFrame(received, expectedFunction, expectedLength)
            If frame IsNot Nothing Then Return frame

            While received.Count > expectedLength * 4
                received.RemoveAt(0)
            End While
        End While

        Throw New TimeoutException("LoRa Modbus response timeout.")
    End Function

    Private Function ExtractFrame(
        received As List(Of Byte),
        expectedFunction As Byte,
        expectedLength As Integer) As Byte()

        Dim index As Integer = 0

        While index <= received.Count - 5
            If received(index) <> _slaveId OrElse
               received(index + 1) <> expectedFunction Then
                index += 1
                Continue While
            End If

            If received.Count - index < expectedLength Then Exit While

            Dim candidate(expectedLength - 1) As Byte

            For i As Integer = 0 To candidate.Length - 1
                candidate(i) = received(index + i)
            Next

            If IsValidCrc(candidate) Then Return candidate

            index += 1
        End While

        If index > 0 Then
            received.RemoveRange(0, Math.Min(index, received.Count))
        End If

        Return Nothing
    End Function

    Private Shared Sub AppendCrc(frame As Byte())
        Dim crc = Crc16(frame, 0, frame.Length - 2)
        frame(frame.Length - 2) = CByte(crc And &HFFUS)
        frame(frame.Length - 1) = CByte((crc >> 8) And &HFFUS)
    End Sub

    Private Shared Function IsValidCrc(frame As Byte()) As Boolean
        Dim received As UShort =
            CUShort(CUInt(frame(frame.Length - 2)) Or
                   (CUInt(frame(frame.Length - 1)) << 8))

        Return received = Crc16(frame, 0, frame.Length - 2)
    End Function

    Private Shared Function Crc16(
        data As Byte(),
        offset As Integer,
        count As Integer) As UShort

        Dim crc As UShort = &HFFFFUS

        For i As Integer = offset To offset + count - 1
            crc = CUShort(crc Xor data(i))

            For bit As Integer = 0 To 7
                crc = If(
                    (crc And 1US) <> 0,
                    CUShort((crc >> 1) Xor &HA001US),
                    CUShort(crc >> 1))
            Next
        Next

        Return crc
    End Function

    Private Shared Sub PutU16(
        buffer As Byte(),
        offset As Integer,
        value As UShort)

        buffer(offset) = CByte((value >> 8) And &HFFUS)
        buffer(offset + 1) = CByte(value And &HFFUS)
    End Sub

    Private Shared Function GetU16(
        buffer As Byte(),
        offset As Integer) As UShort

        Return CUShort(
            (CUInt(buffer(offset)) << 8) Or
            CUInt(buffer(offset + 1)))
    End Function

    Public Sub Dispose() Implements IDisposable.Dispose
        SyncLock _sync
            If _port.IsOpen Then _port.Close()
            _port.Dispose()
        End SyncLock
    End Sub
End Class
