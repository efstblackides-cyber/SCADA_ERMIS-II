Imports System.IO.Ports
Imports System.Text
Imports System.Threading

Partial Public Class ErmisMonitorForm
    Inherits Form

    Private Const ReadStart As UShort = 0US
    Private Const ReadCount As UShort = 105US
    Private Const AckSequenceRegister As UShort = 99US

    Private _modbus As RobustModbusRtuMaster
    Private _cancel As CancellationTokenSource
    Private _pollTask As Task
    Private _lastDisplayedSequence As UInteger
    Private _lastAckedSequence As UInteger

    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub ErmisMonitorForm_Load(
        sender As Object,
        e As EventArgs) Handles MyBase.Load

        RefreshPorts()
        AppendConsole("ERMIS II LoRa Modbus monitor έτοιμο.")
    End Sub

    Private Sub RefreshButton_Click(
        sender As Object,
        e As EventArgs) Handles refreshButton.Click

        RefreshPorts()
    End Sub

    Private Sub ClearButton_Click(
        sender As Object,
        e As EventArgs) Handles clearButton.Click

        outputConsole.Clear()
    End Sub

    Private Async Sub ConnectButton_Click(
        sender As Object,
        e As EventArgs) Handles connectButton.Click

        If _modbus IsNot Nothing Then
            Await DisconnectAsync()
            Return
        End If

        Dim portName = TryCast(comList.SelectedItem, String)

        If String.IsNullOrWhiteSpace(portName) Then
            MessageBox.Show("Επίλεξε πρώτα COM.")
            Return
        End If

        Try
            _modbus = New RobustModbusRtuMaster(
                portName,
                Decimal.ToInt32(baudBox.Value),
                Decimal.ToByte(slaveBox.Value))

            _modbus.Open()

            _cancel = New CancellationTokenSource()
            _pollTask = PollLoopAsync(_cancel.Token)

            SetConnected(True)
            AppendConsole("Συνδέθηκε στη " & portName & ".")

        Catch ex As Exception
            _modbus?.Dispose()
            _modbus = Nothing
            SetConnected(False)
            AppendConsole("ΣΦΑΛΜΑ ΣΥΝΔΕΣΗΣ: " & ex.Message)
        End Try
    End Sub

    Private Async Function PollLoopAsync(token As CancellationToken) As Task
        Dim failedCycles As Integer = 0

        While Not token.IsCancellationRequested
            Dim success As Boolean = False
            Dim errorMessage As String = ""

            Try
                Dim active = _modbus
                If active Is Nothing Then Return

                Dim registers = Await Task.Run(
                    Function()
                        Return active.ReadHoldingRegisters(
                            ReadStart,
                            ReadCount)
                    End Function,
                    token)

                Dim record = TelemetryRecord.FromRegisters(registers)

                If record.Sequence <> 0UI AndAlso
                   record.Sequence <> _lastDisplayedSequence Then

                    _lastDisplayedSequence = record.Sequence
                    BeginInvoke(Sub() ShowRecord(record))
                End If

                If autoAckBox.Checked AndAlso
                   record.Sequence <> 0UI AndAlso
                   record.Sequence <> _lastAckedSequence Then

                    Dim high = CUShort(record.Sequence >> 16)
                    Dim low = CUShort(record.Sequence And &HFFFFUI)

                    Await Task.Run(
                        Sub()
                            active.WriteMultipleRegisters(
                                AckSequenceRegister,
                                New UShort() {high, low})
                        End Sub,
                        token)

                    _lastAckedSequence = record.Sequence
                End If

                failedCycles = 0
                success = True

                BeginInvoke(
                    Sub()
                        statusLabel.Text =
                            $"ONLINE | FIFO {record.FifoCount}/{record.FifoCapacity} | ACK {_lastAckedSequence}"
                    End Sub)

            Catch ex As OperationCanceledException
                Return

            Catch ex As Exception
                failedCycles += 1
                errorMessage = ex.Message
            End Try

            If Not success Then
                BeginInvoke(
                    Sub()
                        statusLabel.Text = $"LoRa retry {failedCycles}"
                        AppendConsole("ΕΠΙΚΟΙΝΩΝΙΑ: " & errorMessage)
                    End Sub)
            End If

            Try
                Await Task.Delay(
                    If(success, 1200, 1800),
                    token)
            Catch ex As OperationCanceledException
                Return
            End Try
        End While
    End Function

    Private Sub ShowRecord(r As TelemetryRecord)
        Dim sb As New StringBuilder()

        sb.AppendLine()
        sb.AppendLine(New String("="c, 82))
        sb.AppendLine(
            $"SEQ: {r.Sequence} | FIFO: {r.FifoCount}/{r.FifoCapacity} | ACK: {r.LastAck}")
        sb.AppendLine(
            $"STATUS: 0x{r.DeviceStatus:X4} | FLAGS: {r.ValidFlags}")

        If (r.ValidFlags And ValidFlags.Sen66) = ValidFlags.Sen66 Then
            sb.AppendLine(
                $"SEN66 PM1={r.SenPm1:F2} PM2.5={r.SenPm25:F2} PM4={r.SenPm4:F2} PM10={r.SenPm10:F2}")
            sb.AppendLine(
                $"      Temp={r.SenTemperature:F2} C RH={r.SenHumidity:F2}% VOC={r.SenVoc:F2} NOx={r.SenNox:F2} CO2={r.SenCo2}")
        End If

        If (r.ValidFlags And ValidFlags.Bmp280) = ValidFlags.Bmp280 Then
            sb.AppendLine(
                $"BMP280 Temp={r.BmpTemperature:F2} C Pressure={r.BmpPressurePa / 100.0F:F2} hPa Altitude={r.BmpAltitude:F2} m")
        End If

        If (r.ValidFlags And ValidFlags.Sht21) = ValidFlags.Sht21 Then
            sb.AppendLine(
                $"SHT21 Temp={r.ShtTemperature:F2} C RH={r.ShtHumidity:F2}%")
        End If

        AppendConsole(sb.ToString().TrimEnd())
    End Sub

    Private Sub RefreshPorts()
        Dim ports = SerialPort.GetPortNames().
            OrderBy(Function(p) p, StringComparer.OrdinalIgnoreCase).
            ToArray()

        comList.Items.Clear()
        comList.Items.AddRange(ports)

        If ports.Length > 0 Then comList.SelectedIndex = 0

        AppendConsole(
            If(
                ports.Length = 0,
                "Δεν βρέθηκαν COM.",
                "Βρέθηκαν: " & String.Join(", ", ports)))
    End Sub

    Private Async Function DisconnectAsync() As Task
        Dim source = _cancel
        Dim runningTask = _pollTask

        _cancel = Nothing
        _pollTask = Nothing

        source?.Cancel()

        If runningTask IsNot Nothing Then
            Try
                Await runningTask
            Catch
            End Try
        End If

        source?.Dispose()
        _modbus?.Dispose()
        _modbus = Nothing

        SetConnected(False)
        AppendConsole("Αποσυνδέθηκε.")
    End Function

    Private Async Sub ErmisMonitorForm_FormClosing(
        sender As Object,
        e As FormClosingEventArgs) Handles MyBase.FormClosing

        Await DisconnectAsync()
    End Sub

    Private Sub SetConnected(value As Boolean)
        connectButton.Text = If(value, "Αποσύνδεση", "Σύνδεση")
        comList.Enabled = Not value
        refreshButton.Enabled = Not value
        baudBox.Enabled = Not value
        slaveBox.Enabled = Not value

        If Not value Then statusLabel.Text = "Αποσυνδεδεμένο"
    End Sub

    Private Sub AppendConsole(message As String)
        If InvokeRequired Then
            BeginInvoke(Sub() AppendConsole(message))
            Return
        End If

        outputConsole.AppendText(
            $"[{DateTime.Now:HH:mm:ss.fff}] {message}{Environment.NewLine}")

        outputConsole.SelectionStart = outputConsole.TextLength
        outputConsole.ScrollToCaret()
    End Sub
End Class
