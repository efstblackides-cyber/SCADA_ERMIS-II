Imports System

<Flags>
Friend Enum ValidFlags As UShort
    None = 0
    Sen66 = 1
    Bmp280 = 2
    Sht21 = 4
    Gps = 8
    FifoOverflow = 16
End Enum

Friend NotInheritable Class TelemetryRecord
    Public Property DeviceStatus As UShort
    Public Property FifoCount As UShort
    Public Property FifoCapacity As UShort
    Public Property Sequence As UInteger
    Public Property LastAck As UInteger
    Public Property ValidFlags As ValidFlags

    Public Property SenPm1 As Single
    Public Property SenPm25 As Single
    Public Property SenPm4 As Single
    Public Property SenPm10 As Single
    Public Property SenTemperature As Single
    Public Property SenHumidity As Single
    Public Property SenVoc As Single
    Public Property SenNox As Single
    Public Property SenCo2 As UShort

    Public Property BmpTemperature As Single
    Public Property BmpPressurePa As Single
    Public Property BmpAltitude As Single
    Public Property ShtTemperature As Single
    Public Property ShtHumidity As Single

    Public Shared Function FromRegisters(r As UShort()) As TelemetryRecord
        If r Is Nothing OrElse r.Length < 105 Then
            Throw New ArgumentException("Ανεπαρκή Modbus registers.")
        End If

        Dim result As New TelemetryRecord With {
            .DeviceStatus = r(1),
            .FifoCount = r(2),
            .FifoCapacity = r(3),
            .Sequence = ReadUInt32(r, 4),
            .LastAck = ReadUInt32(r, 6),
            .ValidFlags = CType(r(14), ValidFlags),
            .SenPm1 = ReadFloat(r, 19),
            .SenPm25 = ReadFloat(r, 21),
            .SenPm4 = ReadFloat(r, 23),
            .SenPm10 = ReadFloat(r, 25),
            .SenTemperature = ReadFloat(r, 27),
            .SenHumidity = ReadFloat(r, 29),
            .SenVoc = ReadFloat(r, 31),
            .SenNox = ReadFloat(r, 33),
            .SenCo2 = r(35),
            .BmpTemperature = ReadFloat(r, 39),
            .BmpPressurePa = ReadFloat(r, 41),
            .BmpAltitude = ReadFloat(r, 43),
            .ShtTemperature = ReadFloat(r, 49),
            .ShtHumidity = ReadFloat(r, 51)
        }

        Return result
    End Function

    Private Shared Function ReadUInt32(r As UShort(), index As Integer) As UInteger
        Return (CUInt(r(index)) << 16) Or CUInt(r(index + 1))
    End Function

    Private Shared Function ReadFloat(r As UShort(), index As Integer) As Single
        Dim raw As UInteger = ReadUInt32(r, index)
        Return BitConverter.Int32BitsToSingle(CInt(raw))
    End Function
End Class
