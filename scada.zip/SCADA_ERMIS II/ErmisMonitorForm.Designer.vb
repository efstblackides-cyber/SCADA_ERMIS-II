Imports System.Drawing
Imports System.Windows.Forms

Partial Public Class ErmisMonitorForm

    Private components As System.ComponentModel.IContainer

    Friend WithEvents topArea As Panel
    Friend WithEvents comList As ListBox
    Friend WithEvents refreshButton As Button
    Friend WithEvents connectButton As Button
    Friend WithEvents clearButton As Button
    Friend WithEvents baudBox As NumericUpDown
    Friend WithEvents slaveBox As NumericUpDown
    Friend WithEvents autoAckBox As CheckBox
    Friend WithEvents outputConsole As RichTextBox
    Friend WithEvents statusLabel As Label
    Friend WithEvents portLabel As Label
    Friend WithEvents baudLabel As Label
    Friend WithEvents slaveLabel As Label

    Protected Overrides Sub Dispose(disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If

        MyBase.Dispose(disposing)
    End Sub

    Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()

        topArea = New Panel()
        comList = New ListBox()
        refreshButton = New Button()
        connectButton = New Button()
        clearButton = New Button()
        baudBox = New NumericUpDown()
        slaveBox = New NumericUpDown()
        autoAckBox = New CheckBox()
        outputConsole = New RichTextBox()
        statusLabel = New Label()
        portLabel = New Label()
        baudLabel = New Label()
        slaveLabel = New Label()

        CType(baudBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(slaveBox, System.ComponentModel.ISupportInitialize).BeginInit()
        topArea.SuspendLayout()
        SuspendLayout()

        topArea.BackColor = SystemColors.Control
        topArea.Controls.Add(portLabel)
        topArea.Controls.Add(comList)
        topArea.Controls.Add(refreshButton)
        topArea.Controls.Add(connectButton)
        topArea.Controls.Add(baudLabel)
        topArea.Controls.Add(baudBox)
        topArea.Controls.Add(slaveLabel)
        topArea.Controls.Add(slaveBox)
        topArea.Controls.Add(autoAckBox)
        topArea.Controls.Add(clearButton)
        topArea.Controls.Add(statusLabel)
        topArea.Dock = DockStyle.Top
        topArea.Location = New Point(0, 0)
        topArea.Name = "topArea"
        topArea.Size = New Size(1100, 140)
        topArea.TabIndex = 0

        portLabel.AutoSize = True
        portLabel.Location = New Point(12, 12)
        portLabel.Name = "portLabel"
        portLabel.Text = "Θύρες COM"

        comList.Font = New Font("Segoe UI", 10.0F)
        comList.FormattingEnabled = True
        comList.Location = New Point(12, 34)
        comList.Name = "comList"
        comList.Size = New Size(180, 89)
        comList.TabIndex = 0

        refreshButton.Location = New Point(205, 34)
        refreshButton.Name = "refreshButton"
        refreshButton.Size = New Size(115, 32)
        refreshButton.TabIndex = 1
        refreshButton.Text = "Ανανέωση"
        refreshButton.UseVisualStyleBackColor = True

        connectButton.Location = New Point(205, 78)
        connectButton.Name = "connectButton"
        connectButton.Size = New Size(115, 46)
        connectButton.TabIndex = 2
        connectButton.Text = "Σύνδεση"
        connectButton.UseVisualStyleBackColor = True

        baudLabel.AutoSize = True
        baudLabel.Location = New Point(345, 12)
        baudLabel.Name = "baudLabel"
        baudLabel.Text = "Baud rate"

        baudBox.Increment = 9600D
        baudBox.Location = New Point(345, 34)
        baudBox.Maximum = 921600D
        baudBox.Minimum = 1200D
        baudBox.Name = "baudBox"
        baudBox.Size = New Size(120, 27)
        baudBox.TabIndex = 3
        baudBox.Value = 115200D

        slaveLabel.AutoSize = True
        slaveLabel.Location = New Point(485, 12)
        slaveLabel.Name = "slaveLabel"
        slaveLabel.Text = "Slave ID"

        slaveBox.Location = New Point(485, 34)
        slaveBox.Maximum = 247D
        slaveBox.Minimum = 1D
        slaveBox.Name = "slaveBox"
        slaveBox.Size = New Size(85, 27)
        slaveBox.TabIndex = 4
        slaveBox.Value = 1D

        autoAckBox.AutoSize = True
        autoAckBox.Checked = True
        autoAckBox.CheckState = CheckState.Checked
        autoAckBox.Location = New Point(345, 82)
        autoAckBox.Name = "autoAckBox"
        autoAckBox.Size = New Size(112, 24)
        autoAckBox.TabIndex = 5
        autoAckBox.Text = "Αυτόματο ACK"
        autoAckBox.UseVisualStyleBackColor = True

        clearButton.Location = New Point(590, 34)
        clearButton.Name = "clearButton"
        clearButton.Size = New Size(125, 32)
        clearButton.TabIndex = 6
        clearButton.Text = "Καθαρισμός"
        clearButton.UseVisualStyleBackColor = True

        statusLabel.AutoSize = True
        statusLabel.Font = New Font("Segoe UI", 10.0F, FontStyle.Bold)
        statusLabel.Location = New Point(590, 86)
        statusLabel.Name = "statusLabel"
        statusLabel.Text = "Αποσυνδεδεμένο"

        outputConsole.BackColor = Color.Black
        outputConsole.BorderStyle = BorderStyle.None
        outputConsole.DetectUrls = False
        outputConsole.Dock = DockStyle.Fill
        outputConsole.Font = New Font("Consolas", 10.0F)
        outputConsole.ForeColor = Color.Lime
        outputConsole.Location = New Point(0, 140)
        outputConsole.Name = "outputConsole"
        outputConsole.ReadOnly = True
        outputConsole.Size = New Size(1100, 580)
        outputConsole.TabIndex = 1
        outputConsole.Text = ""
        outputConsole.WordWrap = False

        AutoScaleDimensions = New SizeF(8.0F, 20.0F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1100, 720)
        Controls.Add(outputConsole)
        Controls.Add(topArea)
        MinimumSize = New Size(850, 550)
        Name = "ErmisMonitorForm"
        StartPosition = FormStartPosition.CenterScreen
        Text = "ERMIS II - LoRa Modbus SCADA Monitor"

        CType(baudBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(slaveBox, System.ComponentModel.ISupportInitialize).EndInit()
        topArea.ResumeLayout(False)
        topArea.PerformLayout()
        ResumeLayout(False)
    End Sub

End Class
